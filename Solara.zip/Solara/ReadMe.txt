Hello. This message is intended only for our users from Russia.

If you get a red line when trying to install Solara, try using a VPN

https://rus.windscribe.net/

https://free-planet-vpn.com/download/

https://github.com/ProtonVPN/win-app/releases/download/3.3.0/ProtonVPN_v3.3.0.exe